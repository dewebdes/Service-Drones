var net = require('net');
//const express = require('express');
//const app = express();
var lastlog = "";
var socketlist = new Array();
var socketips = new Array();
var waiterips = new Array();
var listenerips = new Array();

var server = net.createServer(function(socket) {


socket.on("error", function(err) {
    console.log("Caught flash policy server socket error: ");
    console.log(err.stack);
      try{
        //socket.write("err - "+ err.stack + '\r\n');
        //socket.pipe(socket);
        socket.destroy(); 
      }catch(ex){}
  });

  //socket.write('Echo server\r\n');
  socket.pipe(socket);
  socket.on('data', function(data) {
	if(data.indexOf("*")==-1){
      socket.write("bye" + '\r\n');
      socket.pipe(socket);
      socket.destroy(); 
    
  }
	socket.key = socket.remoteAddress + ":" + socket.remotePort;
	//clients[socket.key] = socket;
	console.log("data recive from: "+socket.key);
    
    if(data.indexOf("/log") > -1){
      //socket.write(lastlog + '\r\n');
      socket.pipe(socket);
      socket.destroy(); 
    }else{



	var request = require('request');
  //.replace("*","").replace("*","")
	var propertiesObject = { ip:socket.key,log:data };

	request({url:'http://telnet.center/samana-addlog', qs:propertiesObject}, function(err, response, body) {
	if(err) { console.log(err); return; }
		console.log('Log saved with id: ' + body);
	});

      console.log('Received: ' + data);
      lastlog = data + "\r\n---------------------------------------------------------------\r\n" + lastlog;
	socketlist[socketlist.length]=socket;
	socketips[socketips.length]=socket.remoteAddress;
	
	for(var i=0;i<=waiterips.length-1;i++){
		if(waiterips[i]==socket.remoteAddress){
			for(var j=0;j<=socketips.length-1;j++){
				if(socketips[j]==listenerips[i]){
					socketlist[j].write('modaladded');
					socketlist[j].pipe(socketlist[j]);
					socketlist[j].destroy();
				}
			}
		}
	}

//addmodal,1,176.9.28.69
	var recivear = data.toString().split(',');
	switch(recivear[0]){
		case "addmodal":
			modalid = recivear[1];
			clientip = recivear[2];
			waiterips[waiterips.length]=clientip;
			listenerips[listenerips.length]=socket.remoteAddress;
		break;
	}
    }
    //socket.destroy(); // kill client after server's response
  });

  socket.on('close', function() {
    console.log('Connection closed');
  });

});


/*app.get('/log', (req, res) => {
    lastlog = util.inspect(req);
    //res.send(req.body);
    res.setHeader("Content-Type", "text/plain;charset=utf-8");
    res.end(lastlog);
});*/

server.listen(80, '176.9.151.236');


/*const http = require('http');

http.createServer((request, response) => {
  const { headers, method, url } = request;
  let body = [];
  request.on('error', (err) => {
    console.error(err);
  }).on('data', (chunk) => {
    body.push(chunk);
    console.log('..data = ' + chunk);
  }).on('end', () => {
    body = Buffer.concat(body).toString();
    // At this point, we have the headers, method, url and body, and can now
    // do whatever we need to in order to respond to this request.
    console.log('..fetig');
  });
  console.log('body = ' + body);
}).listen(80);*/
