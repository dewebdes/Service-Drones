package com.samana.chat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.github.nkzawa.emitter.Emitter;
import com.github.nkzawa.socketio.client.IO;
import com.github.nkzawa.socketio.client.Socket;
import com.google.firebase.iid.FirebaseInstanceId;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;


public class Main2Activity extends AppCompatActivity {
    public static ViewPager viewPager;
    public static Context disact2;
    public static String dieip="";
    public static String wifius="";
    public static String wifipass="";
    public static Map<String,String> progmap =  new HashMap<String,String>();

    public String mytkn = "";

    private final String[] PERMISSIONS = {
            Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    public Socket mSocket;
    {
        try {
            mSocket = IO.socket("http://telnet.center");
        } catch (URISyntaxException e) {}
    }

    public Main2Activity.JavaScriptInterface JSInterface;
    public static WebView NWB1;
    public static WebView NWB2;
    public static WebView NWB3;
    public static WebView NWB4;
    public static WebView NWB5;

    public static String lastact="";
    public String dvid = "0";
    String furl0 = "";
    String furl00 = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        viewPager = (ViewPager) findViewById(R.id.firstrun);

        disact2=this;

        mytkn = FirebaseInstanceId.getInstance().getToken();
        //Toast.makeText(this,tkn, Toast.LENGTH_LONG).show();
        mSocket.connect();
        mSocket.emit("devicedetect", "android,"+mytkn+",samana");
        mSocket.on("setdeviceid", new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                //NWB1.loadUrl("setSeviceId("+args[0].toString()+");");
                dvid =  args[0].toString();
                furl0 = "file:///android_asset/oldapp/app.html?"+dvid;
                furl00 = "file:///android_asset/oldapp/logs.html?" + dvid;
               // NWB1.loadUrl(furl);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        final WebView webView = (WebView) findViewById(R.id.NWB1);
                        webView.loadUrl(furl0);
                        final WebView webView3 = (WebView) findViewById(R.id.NWB3);
                        webView3.loadUrl(furl00);
                    }
                });
            }
        });
        mSocket.on("selectFill", new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                //JSONObject data = (JSONObject)args[0];
//here the data is in JSON Format
                //Toast.makeText(MainActivity.this, data.toString(), Toast.LENGTH_SHORT).show();
                addlog(args[0].toString());
            }
        });

        mSocket.on("selectFill", new Emitter.Listener() {
            @Override
            public void call(Object... args) {

                addlog(args[0].toString());
            }
        });
        //spinner.setVisibility(View.GONE);
        mSocket.on("loginres", new Emitter.Listener() {
            @Override
            public void call(Object... args) {

                loginres(args[0].toString());
            }
        });
        mSocket.on("regres", new Emitter.Listener() {
            @Override
            public void call(Object... args) {

                loginres(args[0].toString());
            }
        });
        //setdevicelist
        mSocket.on("setdevicelist", new Emitter.Listener() {
            @Override
            public void call(Object... args) {

                setdevicelist(args[0].toString());
            }
        });
        mSocket.on("runnotify", new Emitter.Listener() {
            @Override
            public void call(Object... args) {

                //setdevicelist(args[0].toString());
                //viewPager.bringToFront();
                try {
                    spinner.setVisibility(View.GONE);
                }catch (Exception ex){}
            }
        });

        final Handler h = new Handler();
        h.postDelayed(new Runnable()
        {
            private long time = 0;

            @Override
            public void run()
            {
                String tablename = "sam_client";
                String fls = "wifipass,wifius,hubip,devid";
                String vls = wifipass+","+wifius+","+dieip+",{device}";
                String where = "devid={device}";

                switch (lastact){
                    case "getdivelist":
                        lastact="";
                        mSocket.emit("getdivelist", "");
                        break;
                    case "setdivelist":
                        lastact="";
                        NWB5.loadUrl("javascript:admsetup('" + lastdevlist + "');");
                    break;
                    case "getlogs":
                        lastact="";
                        tablename = "sam_logs";
                        fls = "dentry,dtime,deviceid";
                        //String vls = wifipass+","+wifius+","+dieip+",{device}";
                        where = "deviceid=#sq#{device}#sq#";
                        mSocket.emit("select", tablename+"|"+fls+"|"+where);
                        break;
                    case "setloglist":
                        lastact="";
                        NWB3.loadUrl("javascript:setSeviceId();");
                        break;
                    case "reghub":
                        lastact="";
                        tablename = "sam_client";
                        fls = "wifipass,wifius,hubip,devid";
                        vls = "#sq#"+wifipass+"#sq#,#sq#"+wifius+"#sq#,#sq#"+dieip+"#sq#,#sq#{device}#sq#";
                        where = "devid=#sq#{device}#sq#";
                        mSocket.emit("insertorupdate", tablename+"|"+fls+"|"+vls+"|"+where);
                        Toast.makeText(disact2,"reg hub 2", Toast.LENGTH_LONG).show();


                        //insert into wp_sam_client (sid,wifipass,wifius,hubip,devid,ownerTbl,ownerRec,isSingle,isExist,isNew) values(6,123,User,176.9.28.69,
                          //  3,0,0,1,0,0)
                        //insert into wp_sam_client (sid,wifipass,wifius,hubip,devid,ownerTbl,ownerRec,isSingle,isExist,isNew) values(6,#sq#pass#sq#,#sq#us#sq#,#sq#hub#sq#,#sq#devid#sq#,0,0,1,0,0)


                        break;
                    case "regme":
                        lastact="";
                        mSocket.emit("regme", Fname+","+ Fus+","+Fps+","+Fautyp);
                        break;
                    case "userok":
                        lastact="";
                        NWB4.loadUrl("javascript:loginres('"+lastloginres+"');");
                        break;
                    case "startlogin":
                        lastact="";
                        mSocket.emit("loginme", Fus+","+Fps+",mobile");
                        break;

                }
                // do stuff then
                // can call h again after work!
                time += 1000;
                //Log.d("TimerExample", "Going for... " + time);
                h.postDelayed(this, 1000);
            }
        }, 1000);


        //InstanceID instanceID = InstanceID.getInstance(this);

        //String token = instanceID.getToken(getString(R.string.gcm_defaultSenderId),
        //      GoogleCloudMessaging.INSTANCE_ID_SCOPE, null);


        CardFragmentPagerAdapter pagerAdapter = new CardFragmentPagerAdapter(getSupportFragmentManager(), dpToPixels(0, this));
        ShadowTransformer fragmentCardShadowTransformer = new ShadowTransformer(viewPager, pagerAdapter);
        fragmentCardShadowTransformer.enableScaling(true);

        viewPager.setAdapter(pagerAdapter);
        viewPager.setPageTransformer(false, fragmentCardShadowTransformer);
        viewPager.setOffscreenPageLimit(1);

        viewPager.setClipToPadding(false);
        viewPager.setPadding(0,0,0,0);
        viewPager.setPageMargin(10);

        if (!hasPermissions(this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, 1);
        }
        //  viewPager.


        //----------hub
        NWB1 = (WebView) findViewById(R.id.NWB1);
        NWB1.getSettings().setJavaScriptEnabled(true);
        //NWB1.addJavascriptInterface(new WebViewJavaScriptInterface(thisActivity), "app");
        NWB1.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            NWB1.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            NWB1.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        //NWB1.setWebViewClient(new MyBrowser());
        NWB1.getSettings().setLoadsImagesAutomatically(true);
        NWB1.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        NWB1.getSettings().setAppCacheEnabled(false);
        NWB1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        //NWB1.getSettings().setJavaScriptEnabled(true);
        NWB1.getSettings().setDomStorageEnabled(true);
        NWB1.getSettings().setUseWideViewPort(true);
        NWB1.setWebChromeClient(new WebChromeClient());
        NWB1.setScrollbarFadingEnabled(true);
        NWB1.clearCache(true);
        NWB1.setVerticalScrollBarEnabled(false);
        NWB1.getSettings().setAllowUniversalAccessFromFileURLs(true);
        //String furl = "http://transport.maxim.shop/KookiKlub/appFa";
        String furl = "file:///android_asset/oldapp/app.html?"+dvid;


        NWB1.setHorizontalScrollBarEnabled(false);

        JSInterface = new Main2Activity.JavaScriptInterface(this);
        NWB1.addJavascriptInterface(JSInterface, "JSInterface");

      //  NWB1.loadUrl(furl);

    //----------module
        NWB2 = (WebView) findViewById(R.id.NWB2);
        NWB2.getSettings().setJavaScriptEnabled(true);
        //NWB1.addJavascriptInterface(new WebViewJavaScriptInterface(thisActivity), "app");
        NWB2.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            NWB2.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            NWB2.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        //NWB1.setWebViewClient(new MyBrowser());
        NWB2.getSettings().setLoadsImagesAutomatically(true);
        NWB2.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        NWB2.getSettings().setAppCacheEnabled(false);
        NWB2.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        //NWB1.getSettings().setJavaScriptEnabled(true);
        NWB2.getSettings().setDomStorageEnabled(true);
        NWB2.getSettings().setUseWideViewPort(true);
        NWB2.setWebChromeClient(new WebChromeClient());
        NWB2.setScrollbarFadingEnabled(true);
        NWB2.clearCache(true);
        NWB2.setVerticalScrollBarEnabled(false);
        NWB2.getSettings().setAllowUniversalAccessFromFileURLs(true);
        //String furl = "http://transport.maxim.shop/KookiKlub/appFa";
        furl = "file:///android_asset/module/home.html";


        NWB2.setHorizontalScrollBarEnabled(false);

        JSInterface = new Main2Activity.JavaScriptInterface(this);
        NWB2.addJavascriptInterface(JSInterface, "JSInterface");

        NWB2.loadUrl(furl);

        //----------log
        NWB3 = (WebView) findViewById(R.id.NWB3);
        NWB3.getSettings().setJavaScriptEnabled(true);
        //NWB1.addJavascriptInterface(new WebViewJavaScriptInterface(thisActivity), "app");
        NWB3.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            NWB3.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            NWB3.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        //NWB1.setWebViewClient(new MyBrowser());
        NWB3.getSettings().setLoadsImagesAutomatically(true);
        NWB3.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        NWB3.getSettings().setAppCacheEnabled(false);
        NWB3.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        //NWB1.getSettings().setJavaScriptEnabled(true);
        NWB3.getSettings().setDomStorageEnabled(true);
        NWB3.getSettings().setUseWideViewPort(true);
        NWB3.setWebChromeClient(new WebChromeClient());
        NWB3.setScrollbarFadingEnabled(true);
        NWB3.clearCache(true);
        NWB3.setVerticalScrollBarEnabled(false);
        NWB3.getSettings().setAllowUniversalAccessFromFileURLs(true);
        //String furl = "http://transport.maxim.shop/KookiKlub/appFa";
        furl = "file:///android_asset/oldapp/logs.html";


        NWB3.setHorizontalScrollBarEnabled(false);

        JSInterface = new Main2Activity.JavaScriptInterface(this);
        NWB3.addJavascriptInterface(JSInterface, "JSInterface");

      //  NWB3.loadUrl(furl);

        //----------register
        NWB4 = (WebView) findViewById(R.id.NWB4);
        NWB4.getSettings().setJavaScriptEnabled(true);
        //NWB1.addJavascriptInterface(new WebViewJavaScriptInterface(thisActivity), "app");
        NWB4.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            NWB4.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            NWB4.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        //NWB1.setWebViewClient(new MyBrowser());
        NWB4.getSettings().setLoadsImagesAutomatically(true);
        NWB4.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        NWB4.getSettings().setAppCacheEnabled(false);
        NWB4.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        //NWB1.getSettings().setJavaScriptEnabled(true);
        NWB4.getSettings().setDomStorageEnabled(true);
        NWB4.getSettings().setUseWideViewPort(true);
        NWB4.setWebChromeClient(new WebChromeClient());
        NWB4.setScrollbarFadingEnabled(true);
        NWB4.clearCache(true);
        NWB4.setVerticalScrollBarEnabled(false);
        NWB4.getSettings().setAllowUniversalAccessFromFileURLs(true);
        //String furl = "http://transport.maxim.shop/KookiKlub/appFa";
        furl = "file:///android_asset/register/home.html";


        NWB4.setHorizontalScrollBarEnabled(false);

        //----------devicelist
        NWB5 = (WebView) findViewById(R.id.NWB5);
        NWB5.getSettings().setJavaScriptEnabled(true);
        //NWB1.addJavascriptInterface(new WebViewJavaScriptInterface(thisActivity), "app");
        NWB5.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            NWB4.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            NWB4.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        //NWB1.setWebViewClient(new MyBrowser());
        NWB5.getSettings().setLoadsImagesAutomatically(true);
        NWB5.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        NWB5.getSettings().setAppCacheEnabled(false);
        NWB5.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        //NWB1.getSettings().setJavaScriptEnabled(true);
        NWB5.getSettings().setDomStorageEnabled(true);
        NWB5.getSettings().setUseWideViewPort(true);
        NWB5.setWebChromeClient(new WebChromeClient());
        NWB5.setScrollbarFadingEnabled(true);
        NWB5.clearCache(true);
        NWB5.setVerticalScrollBarEnabled(false);
        NWB5.getSettings().setAllowUniversalAccessFromFileURLs(true);
        //String furl = "http://transport.maxim.shop/KookiKlub/appFa";
        furl = "file:///android_asset/admin.html";


        NWB5.setHorizontalScrollBarEnabled(false);

        JSInterface = new Main2Activity.JavaScriptInterface(this);
        NWB5.addJavascriptInterface(JSInterface, "JSInterface");

        NWB5.loadUrl(furl);

        spinner = (ProgressBar)findViewById(R.id.progressBar1);

        continuousTcpClient = new ContinuousTcpClient(TCP_PORT, new ContinuousTcpClient.TcpConnectionListener() {
            public void onDisconnected() {

                //Display("ERROR in connecting :(");
                spinner.setVisibility(View.GONE);

            }


            public void onDataReceived(String message, String ip) {
                //Display("RECIVE from "+ip+": "+message);

            }

            public void onConnected(String hostName, String hostAddress, java.net.Socket s) {
                //Display("OK, connected :)");
                continuousTcpClient.send("addmodal,"+modalid+","+dieip);
            }
        });

    }
    public String lastdevlist="";
    public String lastloglist="";
    void setdevicelist(String str){
        try {

            //JSONObject obj = new JSONObject(str);

            //Log.d("My App", obj.toString());
            JSONArray jsonArray = new JSONArray(str);
            Log.d("My App", jsonArray.toString());
            //"lastip":"::1","prj":"samana","dtkn":"dyhnCXjsH2Q:APA91bFIpVCHsimvjAsV3tV5pop7OpsrykgEH0ip5nkAWjuSn1NOweH7UQLNMaXnSbQvsVKeMahGF4HnD9exn02QKetll3QjqKC3q8Wh1u4gSTfSd8NqP9Yd3rC_IRxnaixuFFr1tBTw","dsys":"android"
          //  JSONArray jsonArray = jsnobject.getJSONArray("locations");
            String htm="";
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    JSONObject explrObject = jsonArray.getJSONObject(i);
                    htm+=explrObject.get("lastip").toString() + " - " + explrObject.get("dsys").toString()+"<br>";
                    Log.d("row: ", htm);
                    //NWB5.loadUrl("javascript:admsetup('" + explrObject.get("lastip").toString() + " - " + explrObject.get("dsys").toString() + "');");
                } catch (Throwable t) {}
            }
lastdevlist=htm;
            Main2Activity.lastact="setdivelist";
            //NWB5.loadUrl("javascript:admsetup('" + lastdevlist + "');");

        } catch (Throwable t) {
            Log.e("My App", "Could not parse malformed JSON: \"" + str + "\"");
        }
//        Toast.makeText(this,str, Toast.LENGTH_LONG).show();
        //NWB5.loadUrl("javascript:admsetup('"+str+"');");
    }
    void addlog(String str){
        //NWB3.loadUrl("javascript:alllog('"+lastloglist+"');");
        try {

            //JSONObject obj = new JSONObject(str);

            //Log.d("My App", obj.toString());
            JSONArray jsonArray = new JSONArray(str);
            Log.d("My App", jsonArray.toString());
            //"lastip":"::1","prj":"samana","dtkn":"dyhnCXjsH2Q:APA91bFIpVCHsimvjAsV3tV5pop7OpsrykgEH0ip5nkAWjuSn1NOweH7UQLNMaXnSbQvsVKeMahGF4HnD9exn02QKetll3QjqKC3q8Wh1u4gSTfSd8NqP9Yd3rC_IRxnaixuFFr1tBTw","dsys":"android"
            //  JSONArray jsonArray = jsnobject.getJSONArray("locations");
            String htm="";
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    JSONObject explrObject = jsonArray.getJSONObject(i);
                    //dentry,dtime,deviceid
                    htm+=explrObject.get("dentry").toString() + " - " + explrObject.get("dtime").toString()+"<br>";
                    Log.d("row: ", htm);
                    //NWB5.loadUrl("javascript:admsetup('" + explrObject.get("lastip").toString() + " - " + explrObject.get("dsys").toString() + "');");
                } catch (Throwable t) {}
            }
            lastloglist=htm;
            Main2Activity.lastact="setloglist";
            //NWB5.loadUrl("javascript:admsetup('" + lastdevlist + "');");

        } catch (Throwable t) {
            Log.e("My App", "Could not parse malformed JSON: \"" + str + "\"");
        }
//        Toast.makeText(this,str, Toast.LENGTH_LONG).show();
        //NWB5.loadUrl("javascript:admsetup('"+str+"');");
    }
    public String lastloginres="";
    void loginres(String str){
        lastloginres=str;

        Main2Activity.lastact="userok";
    }
    public static void getlogs(){

        Main2Activity.lastact="getlogs";

    }
    public static void getdevicelist(){
        //String where = "deviceid={device}";
        //mSocket.emit("getdivelist", "");

    }
    int MYCODE= KeyEvent.KEYCODE_BACK;
    //@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // Result OK.d.
        //Toast.makeText(this,requestCode, Toast.LENGTH_LONG).show();
        if (requestCode == MYCODE) {
            //viewPager.bringToFront();
        }
    }
    @Override
    public void onBackPressed() {
        // your code.
        viewPager.bringToFront();
    }
    private boolean hasPermissions(Context context, String... permissions) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission)
                        != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    private void hideSystemUI() {
        // Enables regular immersive mode.
        // For "lean back" mode, remove SYSTEM_UI_FLAG_IMMERSIVE.
        // Or for "sticky immersive," replace it with SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        // Set the content to appear under the system bars so that the
                        // content doesn't resize when the system bars hide and show.
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        // Hide the nav bar and status bar
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    // Shows the system bars by removing all the flags
// except for the ones that make the content appear under the system bars.
    private void showSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }
    /**
     * Change value in dp to pixels
     * @param dp
     * @param context
     * @return
     */
    public static float dpToPixels(int dp, Context context) {
        return dp * (context.getResources().getDisplayMetrics().density);
    }

    public static void registerhub(){
        //wifipass,wifius,dieip
        /*mSocket.emit("runquery", "samana,registerhub,"+wifipass+","+wifius+","+dieip);
        socket.on('insertorupdate', function(msg){
            //console.log('divice detected: ' + msg);
            var prm = msg.split(",");
            var s_tablename = prm[0];
            var s_flst = prm[1];
            var s_vlst = prm[2];
            var s_where = prm[3];
          */
        Toast.makeText(disact2,"reghub", Toast.LENGTH_LONG).show();
        Main2Activity.lastact="reghub";
    }
    //regme(dieregfullname,dieregmail,ddieregpas,"mobile");
    public static String Fname="";
    public static String Fus="";
    public static String Fps="";
    public static String Fautyp="";
    public static void regme(String name,String us,String ps,String autyp){

        Fname=name;
        Fus=us;
        Fps=ps;
        Fautyp=autyp;
        Main2Activity.lastact="regme";
        //

    }
    public static void getdivelist(){

        Toast.makeText(disact2,"get device list", Toast.LENGTH_LONG).show();
        //mSocket.emit("getdivelist", "");

    }
    public static void loginme(String us,String ps){
Fus=us;
Fps=ps;

        Main2Activity.lastact="startlogin";

    }
    private ContinuousTcpClient continuousTcpClient;
    public final int TCP_PORT = 80;
    public  String centerip = "176.9.151.236";
    String modalid = "";
    private ProgressBar spinner;
    public void manageWBcommands(String msg) {

        //   //Toast.makeText(this,msg, Toast.LENGTH_LONG).show();

//wifipass,wifius,dieip

        String[] foo = msg.split("#np#");
        String cmd = foo[0];
        String param = "";
        try {
            param = foo[1];
        } catch (Exception ex) {
            param = "";
        }

        //register2
        if (cmd.trim().equals("register2")) {
            //+"#np#"++"#np#"++"#np#"++"#np#"++"#np#"++"#np#"++"#np#"++"#np#"+ );
            String dieplat=foo[1];
            String dietkn=foo[2];
            String dieavatarsrc=foo[3];
            String dieregfullname=foo[4];
            String dieregmail=foo[5];
            String ddieregpas=foo[6];
            String ddieregrepas=foo[7];
            String diesendnotify=foo[8];
            String diesendmailnot=foo[9];

            regme(dieregfullname,dieregmail,ddieregpas,"mobile");
            spinner.setVisibility(View.VISIBLE);
            spinner.bringToFront();
        }

        if (cmd.trim().equals("startlogin")) {
            String us=foo[1];
            String pass=foo[2];
            loginme(us,pass);
            spinner.setVisibility(View.VISIBLE);
            spinner.bringToFront();
        }
        if (cmd.trim().equals("addmodule")) {
            modalid=foo[1];
            //mSocket.emit("runquery", "samana,addmodal,"+modalid);
            String tablename = "sam_client";
            String fls = "wifipass,wifius,hubip,devid";
            String vls = wifipass+","+wifius+","+dieip+",{device}";
            String where = "devid={device}";
            //mSocket.emit("insertorupdate", tablename+","+fls+","+vls+","+where);

            spinner.setVisibility(View.VISIBLE);
            spinner.bringToFront();


            continuousTcpClient.connect(centerip, TCP_PORT, new ContinuousTcpClient.ConnectionCallback() {
                public void onConnectionFailed(String ip, Exception e) {
                    //Display("ERROR in connecting :(");
                    spinner.setVisibility(View.GONE);

                }

                public void onConnected(String hostName, String hostAddress) {
                    //Display("OK, connected :)");
                    continuousTcpClient.send("addmodal,"+modalid+","+dieip);
                }
            });




        }
        if (cmd.trim().equals("runBaseSys")) {

            dieip=foo[1];
            wifipass=foo[2];
            wifius=foo[3];
            Toast.makeText(this,"start", Toast.LENGTH_LONG).show();
            // String prm1 = foo[1];
            Intent intent = new Intent(Main2Activity.this, Select.class);
            startActivity(intent);

        }
        //---------------new cmd l-----------------
        if (cmd.trim().equals("injectProg")) {

            /*dieip=foo[1];

            String[] cmdls = foo[2].split("nnll");
            for(int i=0;i<=cmdls.length-1;i++){
                String[] strs = cmdls[i].split("nndd");
                String str2put=strs[0];
                String str2get=strs[1];
                if(!(TextUtils.isEmpty(str2put))&&(!(TextUtils.isEmpty(str2get)))) {
                    Toast.makeText(this,str2put+ " = "+str2get, Toast.LENGTH_LONG).show();
                    progmap.put(str2put, str2get);
                }
            }

            //
            // String prm1 = foo[1];
            Intent intent = new Intent(HubActivity.this, ContinuousTcp1Activity.class);
            startActivity(intent);
            */
        }


    }

    public class WebViewJavaScriptInterface {

        private Context context;

        /*
         * Need a reference to the context in order to sent a post message
         */
        public WebViewJavaScriptInterface(Context context) {
            this.context = context;
        }

        /*
         * This method can be called from Android. @JavascriptInterface
         * required after SDK version 17.
         */
        @JavascriptInterface
        public void makeToast(String message, boolean lengthLong) {

            //((PagerActivity)getActivity()).manageWBcommands(message);
             manageWBcommands(message);

        }
    }
    private class MyBrowser extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }


        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            view.clearCache(true);

            //hideWait();

            /*
            //Toast.makeText(context, message, Toast.LENGTH_LONG).show();
            //wv1.loadUrl("javascript:var msg=window.location.href;app.makeToast(msg, '123');");
            NWB1.loadUrl("javascript:var msg='urlLoaded#np#'+window.location.href;app.makeToast(msg, '123');");

            //--------------------- hack1 ---------------
            String jqCmd = "jQuery('input[type=text]').click(function(){app.makeToast('hideWait', '123');});";
            jqCmd = jqCmd + "jQuery('#doCancel').click(function(){app.makeToast('showWait', '123');});";
            jqCmd = jqCmd + "jQuery('#doPay').click(function(){app.makeToast('showWait', '123');});";
            jqCmd = "if(jQuery('#doPay').length>0){" + jqCmd + "};";
            NWB1.loadUrl("javascript:" + jqCmd);
            //--------------------------------------------
*/

        }
    }

    public class JavaScriptInterface {
        Context mContext;

        /** Instantiate the interface and set the context */
        JavaScriptInterface(Context c) {
            mContext = c;
        }

        @android.webkit.JavascriptInterface
        public void changeActivity(String m)
        {
            manageWBcommands(m);
            //Intent i = new Intent(JavascriptInterfaceActivity.this, nextActivity.class);
            //startActivity(i);
            //finish();
        }
    }

}
