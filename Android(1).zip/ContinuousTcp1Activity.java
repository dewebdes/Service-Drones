package com.samana.chat;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

import saman.zamani.persiandate.PersianDate;

//import com.akexorcist.simpletcp.ContinuousTcpClient;
//import com.akexorcist.simpletcp.TcpUtils;

public class ContinuousTcp1Activity extends AppCompatActivity {
    public final int TCP_PORT = 9999;

    public Map<String,String> map =  new HashMap<String,String>();
    //add items
//map.put("3433fd","Siva");
//get items
    public String str2put = "";
    public String str2get = "";
    public String putmod = "1";
    public String searchMess = "";

    //  String employeeName =(String) map.get("3433fd");

    private Button buttonConnect;
    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;
    private Button button5;
    private Button button6;
    private Button button7;
    private Button button8;
    private Button button9;
    private Button buttonEq;
    private Button buttonAdd;
    private Button buttonGetRep;
    private Button buttonClearout;
    private TextView textViewIpAddress;
    private TextView textViewStatus;
    private EditText editTextIpAddress;

    private ContinuousTcpClient continuousTcpClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_continuous_tcp1);

        map=HubActivity.progmap;

        textViewIpAddress = findViewById(R.id.textViewIpAddress);
        textViewStatus = findViewById(R.id.textViewStatus);
        editTextIpAddress = findViewById(R.id.editTextIpAddress);
        editTextIpAddress.setText(HubActivity.dieip);
        buttonConnect = findViewById(R.id.buttonConnect);
        button1 = findViewById(R.id.button1);
        buttonGetRep = findViewById(R.id.buttonGetRep);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);
        buttonEq = findViewById(R.id.buttonEq);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonClearout = findViewById(R.id.buttonClearout);

        TcpUtils.forceInputIp(editTextIpAddress);
        textViewIpAddress.setText(TcpUtils.getIpAddress(getApplicationContext()));

        buttonConnect.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (buttonConnect.getText().toString().equals("Open")) {
                    buttonConnect.setEnabled(false);
                    editTextIpAddress.setEnabled(false);

                    String ip = editTextIpAddress.getText().toString();
                    continuousTcpClient.connect(ip, TCP_PORT, new ContinuousTcpClient.ConnectionCallback() {
                        public void onConnectionFailed(String ip, Exception e) {
                            textViewStatus.setText("Disconnect");
                            buttonConnect.setEnabled(true);
                            editTextIpAddress.setEnabled(true);
                        }

                        public void onConnected(String hostName, String hostAddress) {
                            textViewStatus.setText("Connect");
                            editTextIpAddress.setEnabled(false);
                            buttonConnect.setEnabled(true);
                            buttonConnect.setText("Close");
                        }
                    });
                } else if (buttonConnect.getText().toString().equals("Close")) {
                    continuousTcpClient.disconnect();
                    textViewStatus.setText("Disconnect");
                    editTextIpAddress.setEnabled(true);
                    buttonConnect.setText("Open");
                }
            }
        });

        buttonGetRep.setOnClickListener(getRepListener);
        button1.setOnClickListener(buttonListener);
        button2.setOnClickListener(buttonListener);
        button3.setOnClickListener(buttonListener);
        button4.setOnClickListener(buttonListener);
        button5.setOnClickListener(buttonListener);
        button6.setOnClickListener(buttonListener);
        button7.setOnClickListener(buttonListener);
        button8.setOnClickListener(buttonListener);
        button9.setOnClickListener(buttonListener);
        buttonEq.setOnClickListener(buttonListener);
        buttonAdd.setOnClickListener(buttonListener);
        buttonClearout.setOnClickListener(buttonListener);

        continuousTcpClient = new ContinuousTcpClient(TCP_PORT, new ContinuousTcpClient.TcpConnectionListener() {
            public void onDisconnected() {
                textViewStatus.setText("Disconnect");
                editTextIpAddress.setEnabled(true);
                buttonConnect.setEnabled(true);
                buttonConnect.setText("Open");
            }

            public void save2db(String ts){
                String offdb="";
                String file = "offdb.js";
                if (true) {

                    try {
                        InputStream inputStream = openFileInput(file);

                        if (inputStream != null) {
                            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                            String receiveString = "";
                            StringBuilder stringBuilder = new StringBuilder();

                            while ((receiveString = bufferedReader.readLine()) != null) {
                                stringBuilder.append(receiveString);
                            }

                            inputStream.close();
                            offdb = stringBuilder.toString();
                        }
                    } catch (FileNotFoundException e) {
                        //Log.e("login activity", "File not found: " + e.toString());
                    } catch (IOException e) {
                        //Log.e("login activity", "Can not read file: " + e.toString());
                    }
                }

                offdb = offdb + ts;
                String filename = file;
                String fileContents = offdb;
                FileOutputStream outputStream;

                try {
                    outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
                    outputStream.write(fileContents.getBytes());
                    outputStream.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                //  Toast.makeText(this,  offdb, Toast.LENGTH_LONG).show();

            }

            public void onDataReceived(String message, String ip) {
                searchMess = message;//searchMess + message;
                String employeeName = "";
                if(map.get(searchMess) != null) {
                    employeeName = (String) map.get(searchMess);
                    PersianDate pdate = new PersianDate();
                    String dt = "typ===report-----id===" + pdate.getTime() + "-----txt===month===" + pdate.monthName() + "-----day===" + pdate.dayName() + "-----time===" + pdate.getHour()+":"+pdate.getMinute() + "-----text===" + message;
                    String d2="offdb[offdb.length] = '"+dt+"';";
                    save2db(d2);

                    Toast.makeText(getApplicationContext(), searchMess+" = "+employeeName, Toast.LENGTH_SHORT).show();
                    if(employeeName != null) {
                        continuousTcpClient.send(employeeName);
                        searchMess = "";
                    }
                }else{
                    String[] separated = searchMess.split(" ");
                    String d2="";
                    for(int i=0;i<=separated.length-1;i++){
                        String[] separated2 = separated[i].split("|");
                        //employeeName = (String) map.get(separated2[separated2.length-1]);
                        PersianDate pdate = new PersianDate();
                        String dt = "typ===report-----id===" + pdate.getTime() + "-----txt===month===" + separated2[0] + "-----day===" + separated2[1] + "-----time===" + separated2[2]+":"+separated2[3]+":"+separated2[4] + "-----text===" + separated2[5];
                        d2+="offdb[offdb.length] = '"+dt+"';";


                        //Toast.makeText(getApplicationContext(), searchMess+" = "+employeeName, Toast.LENGTH_SHORT).show();
                        if(employeeName != null) {
                            continuousTcpClient.send(employeeName);
                            searchMess = "";
                        }
                    }
                    save2db(d2);
                }


            }

            public void onConnected(String hostName, String hostAddress, Socket s) {
                textViewStatus.setText("Connect");
                editTextIpAddress.setText(hostAddress);
                editTextIpAddress.setEnabled(false);
                buttonConnect.setText("Close");
            }
        });
    }

    private View.OnClickListener getRepListener = new View.OnClickListener() {
        public void onClick(View v) {
            continuousTcpClient.send("*REP001*");
        }
    };

    private View.OnClickListener buttonListener = new View.OnClickListener() {
        public void onClick(View v) {
            int id = v.getId();
            // Toast.makeText(getApplicationContext(), id+" = "+((id == R.id.buttonEq)), Toast.LENGTH_SHORT).show();

            if (id == R.id.button1) {
                //continuousTcpClient.send("1");

                if(putmod=="1"){

                    str2put = str2put + "*|2|9|1|*";

                }
                if(putmod=="2"){

                    str2get = str2get + "*|1|3|1|*";

                }

            } else if (id == R.id.button2) {
                //continuousTcpClient.send("2");

                if(putmod=="1"){

                    str2put = str2put + "*|2|9|2|*";

                }
                if(putmod=="2"){

                    str2get = str2get + "*|1|3|2|*";

                }

            } else if (id == R.id.button3) {
                //continuousTcpClient.send("3");
                if(putmod=="1"){

                    str2put = str2put + "*|2|9|3|*";

                }
            } else if (id == R.id.button4) {
                //continuousTcpClient.send("4");
                if(putmod=="1"){

                    str2put = str2put + "*|2|9|4|*";

                }
            } else if (id == R.id.button5) {
                // continuousTcpClient.send("5");
            } else if (id == R.id.button6) {
                // continuousTcpClient.send("6");
            } else if (id == R.id.button7) {
                //  continuousTcpClient.send("7");
            } else if (id == R.id.button8) {
                // continuousTcpClient.send("8");
            } else if (id == R.id.button9) {
                //  continuousTcpClient.send("9");
            }else if (id == R.id.buttonEq) {
                //continuousTcpClient.send("9");

                map.put(str2put,str2get);
                String employeeName =(String) map.get(str2put);
                // Toast.makeText(getApplicationContext(), str2put+" = "+employeeName, Toast.LENGTH_SHORT).show();

                str2put = "";
                putmod = "1";

            }else if (id == R.id.buttonAdd) {
                //continuousTcpClient.send("9");
                //str2put="";
                putmod = "2";
                str2get = "";
            }
            else if (id == R.id.buttonClearout) {
                //continuousTcpClient.send("9");
                //str2put="";
                putmod = "";
                str2get = "";
                searchMess = "";
                putmod = "1";
            }
        }
    };

    public void onResume() {
        super.onResume();
        continuousTcpClient.start();
    }

    public void onStop() {
        super.onStop();
        continuousTcpClient.stop();
    }
}
