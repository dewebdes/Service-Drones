package com.samana.chat;

public class Constant {

    public final static String TRANSFORMATION = "transformation";

    public final static String SLOW_TRANSFORMATION = "slow transformation";
    public final static String SIMPLE_TRANSFORMATION = "simple transformation";
    public final static String DEPTH_TRANSFORMATION = "depth transformation";
    public final static String ZOOM_OUT_TRANSFORMATION = "zoom transformation";
    public final static String CLOCK_SPIN_TRANSFORMATION = "clock_spin  transformation";
    public final static String ANTICLOCK_SPIN_TRANSFORMATION = "anticlock_spin transformation";
    public final static String FIDGET_SPINNER_TRANSFORMATION = "fidget_spinner transformation";
    public final static String VERTICAL_FLIP_TRANSFORMATION = "vertical_flip transformation";
    public final static String HORIZONTAL_FLIP_TRANSFORMATION = "horizontal_flip transformation";
    public final static String POP_TRANSFORMATION = "pop transformation";
    public final static String FADE_OUT_TRANSFORMATION = "fade_out transformation";
    public final static String CUBE_OUT_TRANSFORMATION = "cube_out transformation";
    public final static String CUBE_IN_TRANSFORMATION = "cube_in transformation";
    public final static String CUBE_OUT_SCALING_TRANSFORMATION = "cube_out_scaling transformation";
    public final static String CUBE_IN_SCALING_TRANSFORMATION = "cube_in_scaling transformation";
    public final static String CUBE_OUT_DEPTH_TRANSFORMATION = "cube_out_depth transformation";
    public final static String CUBE_IN_DEPTH_TRANSFORMATION = "cube_in_depth transformation";
    public final static String HINGE_TRANSFORMATION = "hinge transformation";
    public final static String GATE_TRANSFORMATION = "gate transformation";
    public final static String TOSS_TRANSFORMATION = "toss transformation";
    public final static String FAN_TRANSFORMATION = "fan transformation";
    public final static String SPINNER_TRANSFORMATION = "spinner transformation";
    public final static String VERTICAL_SHUT_TRANSFORMATION = "vertical_shut_transformation";
}