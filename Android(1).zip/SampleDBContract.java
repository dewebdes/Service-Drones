package com.samana.chat;

import android.provider.BaseColumns;



/**
 * Created by obaro on 26/09/2016.
 */

public final class SampleDBContract {

    public static final String SELECT_PERSON = "SELECT * " +
            "FROM " + Person.TABLE_NAME ;//+ " ee INNER JOIN " + Employer.TABLE_NAME + " er " +
            //"ON ee." + Employee.COLUMN_EMPLOYER_ID + " = er." + Employer._ID + " WHERE " +
            //"ee." + Employee.COLUMN_FIRSTNAME + " like ? AND ee." + Employee.COLUMN_LASTNAME + " like ?";

    private SampleDBContract() {
    }

    public static class Person implements BaseColumns {
        //public static final String TABLE_NAME = "employer";
        public static final String TABLE_NAME = "naderPERSON";
        public static final String dieplat="dieplat";//foo[0];
        public static final String dietkn="dietkn";//foo[1];
        public static final String dieavatarsrc="dieavatarsrc";//foo[2];
        public static final String dieregfullname="dieregfullname";//foo[3];
        public static final String dieregmail="dieregmail";//foo[4];
        public static final String ddieregpas="ddieregpas";//foo[5];
        public static final String ddieregrepas="ddieregrepas";//foo[6];
        public static final String diesendnotify="diesendnotify";//foo[7];
        public static final String diesendmailnot="diesendmailnot";//foo[8];
        public static final String diedate="diedate";//foo[8];

        public static final String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS " +
                TABLE_NAME + " (" +
                _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                dieplat + " TEXT, " +
                dietkn + " TEXT, " +
                dieavatarsrc + " TEXT, " +
                dieregfullname + " TEXT, " +
                dieregmail + " TEXT, " +
                ddieregpas + " TEXT, " +
                ddieregrepas + " TEXT, " +
                diesendnotify + " TEXT, " +
                diedate + " TEXT, " +
                diesendmailnot + " TEXT)";// +
                //COLUMN_FOUNDED_DATE + " INTEGER" + ")";
    }


}
