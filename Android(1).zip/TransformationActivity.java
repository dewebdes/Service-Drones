package com.samana.chat;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

import com.samana.chat.Fragments.EighthFragment;
import com.samana.chat.Fragments.FifthFragment;
import com.samana.chat.Fragments.FirstFragment;
import com.samana.chat.Fragments.FourthFragment;
import com.samana.chat.Fragments.NinthFragment;
import com.samana.chat.Fragments.SecondFragment;
import com.samana.chat.Fragments.SeventhFragment;
import com.samana.chat.Fragments.SixthFragment;
import com.samana.chat.Fragments.TenthFragment;
import com.samana.chat.Fragments.ThirdFragment;
import com.samana.chat.Transformations.AntiClockSpinTransformation;
import com.samana.chat.Transformations.Clock_SpinTransformation;
import com.samana.chat.Transformations.CubeInDepthTransformation;
import com.samana.chat.Transformations.CubeInRotationTransformation;
import com.samana.chat.Transformations.CubeInScalingTransformation;
import com.samana.chat.Transformations.CubeOutDepthTransformation;
import com.samana.chat.Transformations.CubeOutRotationTransformation;
import com.samana.chat.Transformations.CubeOutScalingTransformation;
import com.samana.chat.Transformations.DepthTransformation;
import com.samana.chat.Transformations.FadeOutTransformation;
import com.samana.chat.Transformations.FanTransformation;
import com.samana.chat.Transformations.FidgetSpinTransformation;
import com.samana.chat.Transformations.GateTransformation;
import com.samana.chat.Transformations.HingeTransformation;
import com.samana.chat.Transformations.HorizontalFlipTransformation;
import com.samana.chat.Transformations.PopTransformation;
import com.samana.chat.Transformations.SimpleTransformation;
import com.samana.chat.Transformations.SlowTransformation;
import com.samana.chat.Transformations.SpinnerTransformation;
import com.samana.chat.Transformations.TossTransformation;
import com.samana.chat.Transformations.VerticalFlipTransformation;
import com.samana.chat.Transformations.VerticalShutTransformation;
import com.samana.chat.Transformations.ZoomOutTransformation;

public class TransformationActivity extends AppCompatActivity {

    ViewPager viewPager;
    MyPagerAdapter pagerAdapter;
    Intent intent;
    public String TRANSFORMATION = "transformation";

    public String SLOW_TRANSFORMATION = "slow transformation";
    public String SIMPLE_TRANSFORMATION = "simple transformation";
    public String DEPTH_TRANSFORMATION = "depth transformation";
    public String ZOOM_OUT_TRANSFORMATION = "zoom transformation";
    public String CLOCK_SPIN_TRANSFORMATION = "clock_spin  transformation";
    public String ANTICLOCK_SPIN_TRANSFORMATION = "anticlock_spin transformation";
    public String FIDGET_SPINNER_TRANSFORMATION = "fidget_spinner transformation";
    public String VERTICAL_FLIP_TRANSFORMATION = "vertical_flip transformation";
    public String HORIZONTAL_FLIP_TRANSFORMATION = "horizontal_flip transformation";
    public String POP_TRANSFORMATION = "pop transformation";
    public String FADE_OUT_TRANSFORMATION = "fade_out transformation";
    public String CUBE_OUT_TRANSFORMATION = "cube_out transformation";
    public String CUBE_IN_TRANSFORMATION = "cube_in transformation";
    public String CUBE_OUT_SCALING_TRANSFORMATION = "cube_out_scaling transformation";
    public String CUBE_IN_SCALING_TRANSFORMATION = "cube_in_scaling transformation";
    public String CUBE_OUT_DEPTH_TRANSFORMATION = "cube_out_depth transformation";
    public String CUBE_IN_DEPTH_TRANSFORMATION = "cube_in_depth transformation";
    public String HINGE_TRANSFORMATION = "hinge transformation";
    public String GATE_TRANSFORMATION = "gate transformation";
    public String TOSS_TRANSFORMATION = "toss transformation";
    public String FAN_TRANSFORMATION = "fan transformation";
    public String SPINNER_TRANSFORMATION = "spinner transformation";
    public String VERTICAL_SHUT_TRANSFORMATION = "vertical_shut_transformation";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transformation);

        viewPager = (ViewPager) findViewById(R.id.viewPager);

        pagerAdapter = new MyPagerAdapter(getSupportFragmentManager());
        addingFragmentsTOpagerAdapter();
        viewPager.setAdapter(pagerAdapter);

        SlowTransformation slowTransformation = new SlowTransformation();
        SimpleTransformation simpleTransformation = new SimpleTransformation();
        DepthTransformation depthTransformation = new DepthTransformation();
        ZoomOutTransformation zoomOutTransformation = new ZoomOutTransformation();
        Clock_SpinTransformation clockSpinTransformation = new Clock_SpinTransformation();
        AntiClockSpinTransformation antiClockSpinTransformation = new AntiClockSpinTransformation();
        FidgetSpinTransformation fidgetSpinTransformation = new FidgetSpinTransformation();
        VerticalFlipTransformation verticalFlipTransformation = new VerticalFlipTransformation();
        HorizontalFlipTransformation horizontalFlipTransformation = new HorizontalFlipTransformation();
        PopTransformation popTransformation = new PopTransformation();
        FadeOutTransformation fadeOutTransformation = new FadeOutTransformation();
        CubeOutRotationTransformation cubeOutRotationTransformation = new CubeOutRotationTransformation();
        CubeInRotationTransformation cubeInRotationTransformation = new CubeInRotationTransformation();
        CubeOutScalingTransformation cubeOutScalingTransformation = new CubeOutScalingTransformation();
        CubeInScalingTransformation cubeInScalingTransformation = new CubeInScalingTransformation();
        CubeOutDepthTransformation cubeOutDepthTransformation = new CubeOutDepthTransformation();
        CubeInDepthTransformation cubeInDepthTransformation = new CubeInDepthTransformation();
        HingeTransformation hingeTransformation = new HingeTransformation();
        GateTransformation gateTransformation = new GateTransformation();
        TossTransformation tossTransformation = new TossTransformation();
        FanTransformation fanTransformation = new FanTransformation();
        SpinnerTransformation spinnerTransformation = new SpinnerTransformation();
        VerticalShutTransformation verticalShutTransformation = new VerticalShutTransformation();


        intent = getIntent();
        String transformation = intent.getStringExtra(TRANSFORMATION);


        switch (transformation) {
            case Constant.SLOW_TRANSFORMATION:
                viewPager.setPageTransformer(true,slowTransformation);
                break;
            case Constant.SIMPLE_TRANSFORMATION:
                viewPager.setPageTransformer(true, simpleTransformation);
                break;
            case Constant.DEPTH_TRANSFORMATION:
                viewPager.setPageTransformer(true, depthTransformation);
                break;
            case Constant.ZOOM_OUT_TRANSFORMATION:
                viewPager.setPageTransformer(true, zoomOutTransformation);
                break;
            case Constant.CLOCK_SPIN_TRANSFORMATION:
                viewPager.setPageTransformer(true, clockSpinTransformation);
                break;
            case Constant.ANTICLOCK_SPIN_TRANSFORMATION:
                viewPager.setPageTransformer(true, antiClockSpinTransformation);
                break;
            case Constant.FIDGET_SPINNER_TRANSFORMATION:
                viewPager.setPageTransformer(true, fidgetSpinTransformation);
                break;
            case Constant.VERTICAL_FLIP_TRANSFORMATION:
                viewPager.setPageTransformer(true, verticalFlipTransformation);
                break;
            case Constant.HORIZONTAL_FLIP_TRANSFORMATION:
                viewPager.setPageTransformer(true, horizontalFlipTransformation);
                break;
            case Constant.POP_TRANSFORMATION:
                viewPager.setPageTransformer(true, popTransformation);
                break;
            case Constant.FADE_OUT_TRANSFORMATION:
                viewPager.setPageTransformer(true, fadeOutTransformation);
                break;
            case Constant.CUBE_OUT_TRANSFORMATION:
                viewPager.setPageTransformer(true, cubeOutRotationTransformation);
                break;
            case Constant.CUBE_IN_TRANSFORMATION:
                viewPager.setPageTransformer(true, cubeInRotationTransformation);
                break;
            case Constant.CUBE_OUT_SCALING_TRANSFORMATION:
                viewPager.setPageTransformer(true, cubeOutScalingTransformation);
                break;
            case Constant.CUBE_IN_SCALING_TRANSFORMATION:
                viewPager.setPageTransformer(true, cubeInScalingTransformation);
                break;
            case Constant.CUBE_OUT_DEPTH_TRANSFORMATION:
                viewPager.setPageTransformer(true, cubeOutDepthTransformation);
                break;
            case Constant.CUBE_IN_DEPTH_TRANSFORMATION:
                viewPager.setPageTransformer(true, cubeInDepthTransformation);
                break;
            case Constant.HINGE_TRANSFORMATION:
                viewPager.setPageTransformer(true, hingeTransformation);
                break;
            case Constant.GATE_TRANSFORMATION:
                viewPager.setPageTransformer(true, gateTransformation);
                break;
            case Constant.TOSS_TRANSFORMATION:
                viewPager.setPageTransformer(true, tossTransformation);
                break;
            case Constant.FAN_TRANSFORMATION:
                viewPager.setPageTransformer(true, fanTransformation);
                break;
            case Constant.SPINNER_TRANSFORMATION:
                viewPager.setPageTransformer(true,spinnerTransformation);
                break;
            case Constant.VERTICAL_SHUT_TRANSFORMATION:
                viewPager.setPageTransformer(true,verticalShutTransformation);
                break;
        }
    }


    private void addingFragmentsTOpagerAdapter() {
        pagerAdapter.addFragments(new FirstFragment());
        pagerAdapter.addFragments(new SecondFragment());
        pagerAdapter.addFragments(new ThirdFragment());
        pagerAdapter.addFragments(new FourthFragment());
        pagerAdapter.addFragments(new FifthFragment());
        pagerAdapter.addFragments(new SixthFragment());
        pagerAdapter.addFragments(new SeventhFragment());
        pagerAdapter.addFragments(new EighthFragment());
        pagerAdapter.addFragments(new NinthFragment());
        pagerAdapter.addFragments(new TenthFragment());
    }

}