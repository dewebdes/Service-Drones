package com.samana.chat;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;


public class CardFragment extends Fragment {

    private CardView cardView;

    public static Fragment getInstance(int position) {
        CardFragment f = new CardFragment();
        Bundle args = new Bundle();
        args.putInt("position", position);
        f.setArguments(args);

        return f;
    }

    @SuppressLint("DefaultLocale")
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.item_viewpager, container, false);

        cardView = (CardView) view.findViewById(R.id.cardView);
        cardView.setMaxCardElevation(cardView.getCardElevation() * CardAdapter.MAX_ELEVATION_FACTOR);

       // TextView title = (TextView) view.findViewById(R.id.title);
        Button button = (Button)view.findViewById(R.id.button);

        //title.setText(String.format("Card %d", getArguments().getInt("position")));

/*
* HOTEL
FLIGHT
VISA
TOUR
TRANSFER
BUS
* */

        ImageView icon = (ImageView) view.findViewById(R.id.iconv);
        int pos = getArguments().getInt("position");
        switch (pos){
            case 0:
                icon.setImageResource(R.drawable.allinone1);
                button.setText("تنظیمات هاب");
                break;
            case 1:
                icon.setImageResource(R.drawable.modaladd);
                button.setText("افزودن ماژول");
                break;
            case 2:
                icon.setImageResource(R.drawable.programmin);
                button.setText("برنامه ریزی");
                break;
            case 3:
                icon.setImageResource(R.drawable.logger);
                button.setText("دریافت لاگ");
                break;
            case 4:
                icon.setImageResource(R.drawable.help);
                button.setText("راهنما");
                break;
            case 5:
                icon.setImageResource(R.drawable.admin);
                button.setText("نسخه ادمین");
                break;
            case 6:
                icon.setImageResource(R.drawable.regist);
                button.setText("ثبت نام");
                break;
            case 7:
                icon.setImageResource(R.drawable.sup);
                button.setText("پشتیبانی");
                break;
        }





        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int pos = getArguments().getInt("position");
                switch (pos){
                    case 0:
                        //Intent intent = new Intent(getActivity(), HubActivity.class);
                        //startActivity(intent);
                        Main2Activity.NWB1.bringToFront();
                        break;
                    case 1:
                        Main2Activity.NWB2.bringToFront();
                        break;
                    case 2:
                        //
                        break;
                    case 3:
                        Main2Activity.NWB3.bringToFront();
                        Main2Activity.getlogs();
                        break;
                    case 4:
                        //
                        break;
                    case 5:
                        Main2Activity.lastact="getdivelist";
                        Main2Activity.NWB5.bringToFront();
                        Main2Activity.getdivelist();
                        break;
                    case 6:
                        Main2Activity.NWB4.bringToFront();
                        break;
                }

                /*
              if(getArguments().getInt("position")==1){
                  Intent intent = new Intent(getActivity(), Main3Activity.class);
                  //EditText editText = (EditText) findViewById(R.id.editText);
                  String message = "hi";//editText.getText().toString();
                  intent.putExtra(EXTRA_MESSAGE, message);
                  startActivity(intent);
              }else {
                  if (getArguments().getInt("position") == 2) {
                      Intent intent = new Intent(getActivity(), MainActivity.class);
                      //EditText editText = (EditText) findViewById(R.id.editText);
                      String message = "hi";//editText.getText().toString();
                      intent.putExtra(EXTRA_MESSAGE, message);
                      startActivity(intent);
                  } else {
                      Toast.makeText(getActivity(), "Button in Card " + getArguments().getInt("position")
                              + "Clicked!", Toast.LENGTH_SHORT).show();
                      Main2Activity.viewPager.setCurrentItem(getArguments().getInt("position") + 1, true);

                  }
              }
              */
            }
        });

        return view;
    }

    public CardView getCardView() {
        return cardView;
    }
}
