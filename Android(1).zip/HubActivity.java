package com.samana.chat;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class HubActivity extends AppCompatActivity {

    public static String dieip="";
    public static String wifius="";
    public static String wifipass="";
    public static Map<String,String> progmap =  new HashMap<String,String>();

    public void savepersons(){
        String file = "peronalin.txt";

        /*String defperson = "isregfon = " + isregfon + "';";
        // defperson = defperson + " var offdb = new Array();"
        defperson = defperson + "mynumber = '" + mynumber + "';";
        defperson = defperson + "mydiscod = '" + mydiscod + "';";
        defperson = defperson + "myparent = '" + myparent + "';";
        defperson = defperson + "mytoken = '" + devToken + "';";

        defperson = defperson + "mygender = '" + mygender + "';";
        defperson = defperson + "myname = '" + myname + "';";
        defperson = defperson + "myfamily = '" + myfamily + "';";
        defperson = defperson + "myemail = '" + myemail + "';";
        defperson = defperson + "myadr = '" + myadr + "';";
        defperson = defperson + "mypass = '" + mypass + "';";

        defperson = defperson + "myotheradresses = '" + myotheradresses + "';";

        defperson = defperson + "mycredit = '" + mycredit + "';";

        defperson = defperson + "myustyp = '" + myustyp + "';";
        defperson = defperson + "myfacs = '" + myfacs + "';";

        String filename = file;
        String fileContents = defperson;
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(fileContents.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        //Toast.makeText(thisActivity, "save finished", Toast.LENGTH_LONG).show();
*/

    }

    public boolean isset(String filename){
        FileInputStream fos = null;
        try {
            fos = openFileInput(filename);
            //fos = openFileInput(getFilesDir()+"/"+filename);
            if (fos != null) {
                return true;
            }else{
                return false;
            }
        } catch (FileNotFoundException e) {
            return false;
        }

        //File file=new File(mContext.getFilesDir(),filename);

        //boolean exists = fos.exists();
    }

    public void checkoffdb() throws IOException {
        /*
        updatepersons();
        String file = "lastupdate.txt";
        if (isset(file) == true) {

            try {
                InputStream inputStream = openFileInput(file);

                if (inputStream != null) {
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    String receiveString = "";
                    StringBuilder stringBuilder = new StringBuilder();

                    while ((receiveString = bufferedReader.readLine()) != null) {
                        stringBuilder.append(receiveString);
                    }

                    inputStream.close();
                    lastupdt = stringBuilder.toString();
                }
            } catch (FileNotFoundException e) {
                //Log.e("login activity", "File not found: " + e.toString());
            } catch (IOException e) {
                //Log.e("login activity", "Can not read file: " + e.toString());
            }
        }

        file = "offdb.txt";
        if (isset(file) == true) {

            try {
                InputStream inputStream = openFileInput(file);

                if (inputStream != null) {
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    String receiveString = "";
                    StringBuilder stringBuilder = new StringBuilder();

                    while ((receiveString = bufferedReader.readLine()) != null) {
                        stringBuilder.append(receiveString);
                    }

                    inputStream.close();
                    offdb = stringBuilder.toString();
                }
            } catch (FileNotFoundException e) {
                //Log.e("login activity", "File not found: " + e.toString());
            } catch (IOException e) {
                //Log.e("login activity", "Can not read file: " + e.toString());
            }
        }


        offdb = offdb.trim();
        lastupdt = lastupdt.trim();

        boolean isLastUpdateNull = ((lastupdt == "") || (lastupdt == "0"));
        boolean isLastDBNull = ((offdb == "") || (offdb == "0"));
        boolean need2update = (isLastUpdateNull && isLastDBNull);

        need2update=true;
        if (need2update == true) getNewDB();

        if (need2update == false) {


            if (isLastDBNull == false) {
                loadDBinRam();
            }
            AsyncHttpClient client = new AsyncHttpClient();
            final RequestHandle requestHandle = client.get(("http://transport.maxim.shop/OffLine/need2update?upd=" + lastupdt), new AsyncHttpResponseHandler() {

                @Override
                public void onStart() {
                    // called before request is started
                }



                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] response) {
                    // called when response HTTP status is "200 OK"
                    lastresp= response.toString();
                    String needup = lastresp;
                    if (needup == "y") {
                        try {
                            getNewDB();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                        loadDBinRam();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e) {
                    // called when response HTTP status is "4XX" (eg. 401, 403, 404)
                }

                @Override
                public void onRetry(int retryNo) {
                    // called when request is retried
                }
            });



        }

        baseScript="";
        String[] lines=offdb.split("$$$$$\r");
        for(int i=0;i<=lines.length-1;i++){
            baseScript = baseScript + "offdb[offdb.length] = '" + (lines[i]) + "';";
        }
        //write fildb.js

        //   //Toast.makeText(thisActivity, ""+lines.length, Toast.LENGTH_LONG).show();


        String defperson = "isregfon = " + isregfon + ";";
        // defperson = defperson + " var offdb = new Array();"
        defperson = defperson + " mynumber = '" + mynumber + "';";
        defperson = defperson + " mydiscod = '" + mydiscod + "';";
        defperson = defperson + " myparent = '" + myparent + "';";
        defperson = defperson + " mytoken = '" + devToken + "';";

        defperson = defperson + " mygender = '" + mygender + "';";
        defperson = defperson + " myname = '" + myname + "';";
        defperson = defperson + " myfamily = '" + myfamily + "';";
        defperson = defperson + " myemail = '" + myemail + "';";
        defperson = defperson + " myadr = '" + myadr + "';";
        defperson = defperson + " mypass = '" + mypass + "';";

        defperson = defperson + " myotheradresses = '" + myotheradresses + "';";

        defperson = defperson + " mycredit = '" + mycredit + "';";

        defperson = defperson + " myustyp = '" + myustyp + "';";
        defperson = defperson + " myfacs = '" + myfacs + "';setupme();";


        baseScript = defperson;// baseScript + defperson;

        //offdb="okl";
        ////Toast.makeText(thisActivity,  lastupdt + "len is: "+offdb.length(), Toast.LENGTH_LONG).show();
        */
    }

    public String lastupdt="";
    public String offdb="";

    public void createdb(){
        String file = "offdb.js";
        String filename = file;
        String fileContents = "alert(123);";
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(fileContents.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void  remove2db(String ts){
        String file = "offdb.js";


        offdb = offdb.replaceAll(ts,"");// + ts;
        String filename = file;
        String fileContents = offdb;
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(fileContents.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Toast.makeText(this,  "please reset app :)", Toast.LENGTH_LONG).show();

    }
    public void  remove2db2(String ts){
        String file = "offdb.js";

        //var d2='offdb[offdb.length] = "'+dt+'";';
        String newodd="";
        String[] separated = offdb.split(";");
        for(int i=0;i<=separated.length-1;i++){

            if(separated[i].contains(ts)==true){
                separated[i]="";
            }else{
                newodd+=separated[i];
            }

        }

        offdb = newodd;//offdb.replaceAll(ts,"");// + ts;
        String filename = file;
        String fileContents = offdb;
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(fileContents.getBytes());
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Toast.makeText(this,  "2222please reset app :)", Toast.LENGTH_LONG).show();

    }
    public void save2db(String ts){
        String file = "offdb.js";
        if (isset(file) == true) {

            try {
                InputStream inputStream = openFileInput(file);

                if (inputStream != null) {
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    String receiveString = "";
                    StringBuilder stringBuilder = new StringBuilder();

                    while ((receiveString = bufferedReader.readLine()) != null) {
                        stringBuilder.append(receiveString);
                    }

                    inputStream.close();
                    offdb = stringBuilder.toString();
                }
            } catch (FileNotFoundException e) {
                //Log.e("login activity", "File not found: " + e.toString());
            } catch (IOException e) {
                //Log.e("login activity", "Can not read file: " + e.toString());
            }
        }

        offdb = offdb + ts;
        String filename = file;
        String fileContents = offdb;
        FileOutputStream outputStream;

        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            outputStream.write(fileContents.getBytes());
            outputStream.close();
        } catch (Exception e) {
            Toast.makeText(this,  e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }

        // Toast.makeText(this,  offdb, Toast.LENGTH_LONG).show();

    }
    public void readdb(){
        String file = "lastupdate.txt";
        if (isset(file) == true) {

            try {
                InputStream inputStream = openFileInput(file);

                if (inputStream != null) {
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    String receiveString = "";
                    StringBuilder stringBuilder = new StringBuilder();

                    while ((receiveString = bufferedReader.readLine()) != null) {
                        stringBuilder.append(receiveString);
                    }

                    inputStream.close();
                    lastupdt = stringBuilder.toString();
                }
            } catch (FileNotFoundException e) {
                //Log.e("login activity", "File not found: " + e.toString());
            } catch (IOException e) {
                //Log.e("login activity", "Can not read file: " + e.toString());
            }
        }

        file = "offdb.txt";
        if (isset(file) == true) {

            try {
                InputStream inputStream = openFileInput(file);

                if (inputStream != null) {
                    InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    String receiveString = "";
                    StringBuilder stringBuilder = new StringBuilder();

                    while ((receiveString = bufferedReader.readLine()) != null) {
                        stringBuilder.append(receiveString);
                    }

                    inputStream.close();
                    offdb = stringBuilder.toString();
                }
            } catch (FileNotFoundException e) {
                //Log.e("login activity", "File not found: " + e.toString());
            } catch (IOException e) {
                //Log.e("login activity", "Can not read file: " + e.toString());
            }
        }


    }

    public JavaScriptInterface JSInterface;
    public WebView NWB1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        save2db("");
        setContentView(R.layout.activity_hub);

        //createdb();



     //   setContentView(R.layout.activity_main);


        //wv = (WebView) findViewById(R.id.NWB1);
        //wv.loadUrl("file:///android_asset/appWB.html");   // now it will not fail here

        NWB1 = (WebView) findViewById(R.id.NWB1);
        NWB1.getSettings().setJavaScriptEnabled(true);
        //NWB1.addJavascriptInterface(new WebViewJavaScriptInterface(thisActivity), "app");
        NWB1.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            NWB1.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            NWB1.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        //NWB1.setWebViewClient(new MyBrowser());
        NWB1.getSettings().setLoadsImagesAutomatically(true);
        NWB1.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        NWB1.getSettings().setAppCacheEnabled(false);
        NWB1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        //NWB1.getSettings().setJavaScriptEnabled(true);
        NWB1.getSettings().setDomStorageEnabled(true);
        NWB1.getSettings().setUseWideViewPort(true);
        NWB1.setWebChromeClient(new WebChromeClient());
        NWB1.setScrollbarFadingEnabled(true);
        NWB1.clearCache(true);
        NWB1.setVerticalScrollBarEnabled(false);
        NWB1.getSettings().setAllowUniversalAccessFromFileURLs(true);
        //String furl = "http://transport.maxim.shop/KookiKlub/appFa";
        String furl = "file:///android_asset/oldapp/app.html";


        NWB1.setHorizontalScrollBarEnabled(false);

        JSInterface = new JavaScriptInterface(this);
        NWB1.addJavascriptInterface(JSInterface, "JSInterface");

        NWB1.loadUrl(furl);
       /* StringBuilder buf=new StringBuilder();
        InputStream json= null;
        BufferedReader in=
                null;
        String str="";
        try {
            json = getAssets().open("app.html");
            in = new BufferedReader(new InputStreamReader(json, "UTF-8"));
            while ((str=in.readLine()) != null) {
                buf.append(str);
            }

            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


        //NWB1.loadData(str, "text/html", null);
        Toast.makeText(this,str, Toast.LENGTH_LONG).show();
        NWB1.loadData(str, "text/html; charset=utf-8", "UTF-8");
*/

        NWB1.setWebViewClient(new WebViewClient() {
            @Override
            public void onLoadResource (WebView view, String url){

                ////Toast.makeText(getContext(), "+++ on load res call", Toast.LENGTH_LONG).show();
            }
            public void onPageFinished (WebView view, String url){
                // //Toast.makeText(thisActivity, "is: "+baseScript.length(), Toast.LENGTH_LONG).show();
                super.onPageFinished(view, url);

            }

        });
    }

    public void manageWBcommands(String msg) {

        //   //Toast.makeText(this,msg, Toast.LENGTH_LONG).show();


        String[] foo = msg.split("#np#");
        String cmd = foo[0];
        String param = "";
        try {
            param = foo[1];
        } catch (Exception ex) {
            param = "";
        }

        if (cmd.trim().equals("getdb")) {

        }
        //---------------new cmd l-----------------
        if (cmd.trim().equals("injectProg")) {

            dieip=foo[1];

            String[] cmdls = foo[2].split("nnll");
            for(int i=0;i<=cmdls.length-1;i++){
                String[] strs = cmdls[i].split("nndd");
                String str2put=strs[0];
                String str2get=strs[1];
                if(!(TextUtils.isEmpty(str2put))&&(!(TextUtils.isEmpty(str2get)))) {
                    Toast.makeText(this,str2put+ " = "+str2get, Toast.LENGTH_LONG).show();
                    progmap.put(str2put, str2get);
                }
            }

            //
            // String prm1 = foo[1];
            Intent intent = new Intent(HubActivity.this, ContinuousTcp1Activity.class);
            startActivity(intent);

        }
        if (cmd.trim().equals("runBaseSys")) {

            dieip=foo[1];
            wifipass=foo[2];
            wifius=foo[3];
            Toast.makeText(this,"start", Toast.LENGTH_LONG).show();
            // String prm1 = foo[1];
            Intent intent = new Intent(HubActivity.this, Select.class);
            startActivity(intent);

        }
        if (cmd.trim().equals("save2db")) {

            String prm1 = foo[1];

            save2db(prm1);
            //  Toast.makeText(this,prm1, Toast.LENGTH_LONG).show();
            NWB1.loadUrl("javascript:" + "hideWait();");
        }
        if (cmd.trim().equals("remove2db2")) {
            String prm1 = foo[1];
            remove2db2(prm1);
        }
        if (cmd.trim().equals("remove2db")) {
            String prm1 = foo[1];
            remove2db(prm1);
        }
        if (cmd.trim().equals("doalert")) {

            String prm1 = foo[1];

            Toast.makeText(this,prm1, Toast.LENGTH_LONG).show();

        }

    }

    public class WebViewJavaScriptInterface {

        private Context context;

        /*
         * Need a reference to the context in order to sent a post message
         */
        public WebViewJavaScriptInterface(Context context) {
            this.context = context;
        }

        /*
         * This method can be called from Android. @JavascriptInterface
         * required after SDK version 17.
         */
        @JavascriptInterface
        public void makeToast(String message, boolean lengthLong) {

            //((PagerActivity)getActivity()).manageWBcommands(message);
            // manageWBcommands(message);

        }
    }
    private class MyBrowser extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }


        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            view.clearCache(true);

            //hideWait();

            /*
            //Toast.makeText(context, message, Toast.LENGTH_LONG).show();
            //wv1.loadUrl("javascript:var msg=window.location.href;app.makeToast(msg, '123');");
            NWB1.loadUrl("javascript:var msg='urlLoaded#np#'+window.location.href;app.makeToast(msg, '123');");

            //--------------------- hack1 ---------------
            String jqCmd = "jQuery('input[type=text]').click(function(){app.makeToast('hideWait', '123');});";
            jqCmd = jqCmd + "jQuery('#doCancel').click(function(){app.makeToast('showWait', '123');});";
            jqCmd = jqCmd + "jQuery('#doPay').click(function(){app.makeToast('showWait', '123');});";
            jqCmd = "if(jQuery('#doPay').length>0){" + jqCmd + "};";
            NWB1.loadUrl("javascript:" + jqCmd);
            //--------------------------------------------
*/

        }
    }

    public static class JavaScriptInterface {
        Context mContext;

        /** Instantiate the interface and set the context */
        JavaScriptInterface(Context c) {
            mContext = c;
        }

        @android.webkit.JavascriptInterface
        public void changeActivity(String m)
        {
            //manageWBcommands(m);
            //Intent i = new Intent(JavascriptInterfaceActivity.this, nextActivity.class);
            //startActivity(i);
            //finish();
        }
    }


}
